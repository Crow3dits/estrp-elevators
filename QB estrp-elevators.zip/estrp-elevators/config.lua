Config = {}

Config.TextUI = true

Config.Elevator = {
    ['FIB Building'] = {
        {
            coords = vector4(136.7511, -762.9361, 242.1519, 187.4600),
            label = "49th Floor",
            description = "49-nth floor in FIB building"
        },
        {
            coords = vector4(136.2310, -761.9385, 234.1520, 149.8514),
            label = "47th Floor",
            description = "47-th floor in FIB building"
        },
        {
            coords = vector4(135.9060, -762.2665, 45.7520, 155.6413),
            label = "1st floor",
            description = "First floor in FIB building"
        },
        jobrequiered = true, --- If no job requirement then: jobrequiered = false,
        jobs = {"ambulance", "police"}, --- if no job requirement then: jobs = nil,
    },
}